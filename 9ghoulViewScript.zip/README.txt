This is a simple view script that gives you views on videos made with python.

The owner of this script is @9ghoul.